import React from "react";
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import AddEmployee from "../AddEmployee/AddEmployee";
import AddRole from "../AddRole/AddRole";
import DeleteEmployee from "../DeleteEmployee/DeleteEmployee";
import SideNavBar from "../SideNavBar/SideNavBar";
import UpdateRole from "../UpdateRole/UpdateRole";

const navs = [
    {
        url:'/admin/addemp',
        name:'Add employee'
    },
    {
        url:'/admin/deleteEmp',
        name:'Delete employee'
    },
    {
        url:'/admin/addRole',
        name:'Add Role'
    },
    {
        url:'/admin/updateRole',
        name:'Update Role'
    }
];

const AdminDashboard = (props) => {
  return (
    <div>
      <Router>
        {/* <Switch> */}
        <SideNavBar navs={navs}/>
        <Route path="/admin/addemp" component={AddEmployee}></Route>
        <Route path="/admin/addrole" component={AddRole}></Route>
        <Route path="/admin/updateRole" component={UpdateRole}></Route>
        <Route path="/admin/deleteEmp" component={DeleteEmployee}></Route>
        {/* </Switch> */}
      </Router>
    </div>
  );
};

export default AdminDashboard;
