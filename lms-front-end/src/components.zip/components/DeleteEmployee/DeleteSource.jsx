import React, { Component } from 'react';

class DeleteSource extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            employees:[]
         }
    }
    render() { 
        return (<div>
            
        </div> );
    }
}
 
export default DeleteSource;