import React from "react";
import SideNavBar from "../SideNavBar/SideNavBar";
import { BrowserRouter as Router, Link, Route, Switch } from "react-router-dom";
import AddLoanType from "../LoanType/AddLoanType";
import UpdateLoanType from "../LoanType/UpdateLoanType";
import AddClient from "../AddClient/AddClient";
import ApprovedApplications from "../ApprovedApplications/ApprovedApplications";
import PendingApplications from "../PendingApplications/PendingApplications";

const navs = [
  {
    url: "/employee/apprLoans",
    name: "Approved Applications",
  },
  {
    url: "/employee/pendLoans",
    name: "Pending Applications",
  },
  {
    url: "/employee/addclient",
    name: "Add Client",
  },
  {
    url: "/employee/updateclient",
    name: "Update Client",
  },
  {
    url: "/employee/deleteclient",
    name: "Delete Client",
  },
  {
    url: "/employee/addloantype",
    name: "Add Loan Type",
  },
  {
    url: "/employee/updateloantype",
    name: "Update Loan type",
  },
];

const EmployeeDashboard = (props) => {
  return (
    <div>
        <Router>

      <SideNavBar navs={navs} />

      <Route path='/employee/apprLoans' component={ApprovedApplications}> </Route>
      <Route path="/employee/pendLoans" component={PendingApplications}></Route>
      <Route path='/employee/addloantype' component={AddLoanType}></Route>
      <Route path='/employee/updateloantype' component={UpdateLoanType}></Route>
      <Route path='/employee/addclient' component={AddClient}></Route>
        </Router>
    </div>
  );
};

export default EmployeeDashboard;
